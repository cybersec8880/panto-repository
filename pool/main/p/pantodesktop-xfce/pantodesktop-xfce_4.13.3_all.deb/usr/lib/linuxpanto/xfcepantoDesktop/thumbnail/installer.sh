if [ ! -f /usr/bin/mplayer ];then
	/usr/lib/linuxpanto/pantoDesktop-xfce/mplayer/mplayerinstall.py
fi

if [ -f /usr/share/thumbnailers/video-thumbs.desktop ];	then	
	gksu chmod 755 /usr/share/thumbnailers/video-thumbs.desktop 		
else
	gksu cp /usr/lib/linuxpanto/xfcepantoDesktop/thumbnail/video-thumbs.desktop /usr/share/thumbnailers/
fi
if [ -f /usr/lib/thunar/mplayer-thumbnailer ];then
	gksu chmod 755 /usr/lib/thunar/mplayer-thumbnailer
else
	gksu cp /usr/lib/linuxpanto/xfcepantoDesktop/thumbnail/mplayer-thumbnailer /usr/lib/thunar/
fi
if [  ! -f /usr/bin/mplayer  ];then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails false
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails true
fi
if [  ! -f /usr/share/thumbnailers/video-thumbs.desktop ];then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails false
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails true
fi
/usr/lib/thunar/thunar-vfs-update-thumbnailers-cache-1