if [ ! -d $HOME/.config/autostart ]
then
	mkdir $HOME/.config/autostart
fi
if [ -r $HOME/.config/autostart/Compiz_Fusion.desktop ]
then
	rm -r $HOME/.config/autostart/Compiz_Fusion.desktop
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_auto true	
else
	cp /usr/lib/linuxpanto/xfcepantoDesktop/desktopeffects/Compiz_Fusion.desktop $HOME/.config/autostart/
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_auto false
fi