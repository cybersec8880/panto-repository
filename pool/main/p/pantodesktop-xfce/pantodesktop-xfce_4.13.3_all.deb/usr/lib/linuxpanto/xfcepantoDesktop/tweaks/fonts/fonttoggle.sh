#!/bin/bash

if [ -r $HOME/.fonts.conf ]
then
	rm -r $HOME/.fonts.conf
else
	
	cp /usr/lib/linuxpanto/xfcepantoDesktop/tweaks/fonts/.fonts.conf $HOME/
fi