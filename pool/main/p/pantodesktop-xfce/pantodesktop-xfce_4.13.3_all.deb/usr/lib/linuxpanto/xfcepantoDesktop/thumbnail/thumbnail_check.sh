#!/bin/sh
if [ ! -f /usr/share/thumbnailers/video-thumbs.desktop ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails false
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails true
fi
