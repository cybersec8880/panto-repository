#!/bin/bash
if [ -x /usr/bin/numlockx ]; then /usr/bin/numlockx off || /bin/false; fi