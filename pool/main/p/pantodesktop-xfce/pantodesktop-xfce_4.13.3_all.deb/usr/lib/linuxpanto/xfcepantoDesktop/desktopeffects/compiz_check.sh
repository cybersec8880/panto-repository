#!/bin/sh
if [ -r $HOME/.config/autostart/Compiz_Fusion.desktop ]
then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_auto true	
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_auto false
fi
if pidof compiz | grep [0-9] > /dev/null
then
gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_fusion true
else
gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_fusion false
fi 