#!/usr/bin/env python

# pantoAssistant
#	No Copyright (What for?) Clem <root@linuxpanto.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; Version 2
# of the License.

import sys
try:
     import pygtk
     pygtk.require("2.0")
except:
      pass
try:
    import gtk
    import gtk.glade
    import commands
    import os
    import gettext
except:
    print "You do not have all the dependencies!"
    sys.exit(1)

# i18n
gettext.install("messages", "/usr/lib/linuxpanto/xfcepantoDesktop/locale")

class CompizCheck:
    """CompizCheck"""
    def __init__(self):
        #Set the Glade file
        self.gladefile = "/usr/lib/linuxpanto/xfcepantoDesktop/desktopeffects/compiz.glade"
        self.wTree = gtk.glade.XML(self.gladefile,"window1")
	self.wTree.get_widget("window1").connect("destroy",gtk.main_quit)
	self.wTree.get_widget("close_button").connect("clicked",gtk.main_quit)
	self.wTree.get_widget("refresh_button").connect("clicked", self.showFortune)

	#i18n
	self.wTree.get_widget("compiz_label").set_text(_("<big><b>Compiz System Check</b></big>"))
	self.wTree.get_widget("compiz_label").set_use_markup(True)

	fortune = commands.getoutput("/usr/lib/linuxpanto/xfcepantoDesktop/desktopeffects/compiz-check")
	buffer = gtk.TextBuffer()
	buffer.set_text(fortune)
	self.wTree.get_widget("test_text").set_buffer(buffer)

    def showFortune(self, widget):
	fortune = commands.getoutput("/usr/lib/linuxpanto/xfcepantoDesktop/desktopeffects/compiz-check")
	buffer = gtk.TextBuffer()
	buffer.set_text(fortune)
	self.wTree.get_widget("test_text").set_buffer(buffer)
	self.wTree.get_widget("refresh_button").set_sensitive(True)

if __name__ == "__main__":
	APPDOMAIN='CompizCheck'
	LANGDIR='lang'
	# locale
	gtk.glade.bindtextdomain(APPDOMAIN, LANGDIR)
	gtk.glade.textdomain(APPDOMAIN)
	rec = CompizCheck()
	# run gui
	gtk.main()


