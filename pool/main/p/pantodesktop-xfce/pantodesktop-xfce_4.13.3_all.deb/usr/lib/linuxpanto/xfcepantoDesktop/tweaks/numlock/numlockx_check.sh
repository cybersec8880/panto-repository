#!/bin/bash
if [ -f /etc/X11/Xsession.d/60numlockx ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/numlockx true
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/numlockx false
fi