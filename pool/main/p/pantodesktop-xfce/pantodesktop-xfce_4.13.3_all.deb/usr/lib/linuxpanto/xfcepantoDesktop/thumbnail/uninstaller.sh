if [ -d $HOME/.thumbnails/normal ];then
	rm -R $HOME/.thumbnails/normal
fi
if [ -d $HOME/.thumbnails/fail ];then
	rm -R $HOME/.thumbnails/fail
fi
if [ -f /usr/share/thumbnailers/video-thumbs.desktop ]; then
	gksu rm /usr/share/thumbnailers/video-thumbs.desktop
fi
/usr/lib/thunar/thunar-vfs-update-thumbnailers-cache-1
if [ ! -f /usr/share/thumbnailers/video-thumbs.desktop ];then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/thumbnails false
fi