#!/bin/sh
restartx=$(gconftool-2 --get /apps/pantodesktop-xfce/cab_toggle)
if [ "$restartx" = "false" ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/cab_toggle true
	setxkbmap -option terminate:ctrl_alt_bksp
elif [ "$restartx" = "true" ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/cab_toggle false
elif [ "$restartx" = "" ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/cab_toggle true
	setxkbmap -option terminate:ctrl_alt_bksp
else
	exit 0
fi