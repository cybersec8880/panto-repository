if pidof compiz | grep [0-9] > /dev/null
then
killall compiz.real
killall compiz
killall emerald
xfwm4 --replace &
gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_fusion false
else
killall xfwm4
compiz --replace &
gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_fusion true
fi 
sleep 2
if pidof compiz | grep [0-9] > /dev/null
then
gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_fusion true
else
gconftool-2 --type bool --set /apps/pantodesktop-xfce/compiz_fusion false
fi