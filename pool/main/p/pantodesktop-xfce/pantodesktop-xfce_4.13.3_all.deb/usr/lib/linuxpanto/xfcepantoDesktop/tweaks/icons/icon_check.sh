#!/bin/bash
white=$(cat $HOME/.gtkrc-2.0 | grep -i include | grep -i .gtkrc-white | wc -l)
black=$(cat $HOME/.gtkrc-2.0 | grep -i include | grep -i .gtkrc-black | wc -l)
if [ "$black" = "1" ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_black true
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_black false
fi
if [ "$white" = "1" ]; then
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_white true
else
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_white false
fi