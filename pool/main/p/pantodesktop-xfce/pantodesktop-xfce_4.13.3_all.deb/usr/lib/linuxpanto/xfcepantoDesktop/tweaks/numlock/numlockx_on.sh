#!/bin/bash
if [ -x /usr/bin/numlockx ]; then /usr/bin/numlockx on || /bin/true; fi