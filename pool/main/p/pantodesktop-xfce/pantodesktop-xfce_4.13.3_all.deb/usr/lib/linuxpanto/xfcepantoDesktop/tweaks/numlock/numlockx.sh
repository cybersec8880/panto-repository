#!/bin/bash
if [ ! -f /etc/X11/Xsession.d/60numlockx ]; then
	gksu cp /usr/lib/linuxpanto/xfcepantoDesktop/tweaks/numlock/60numlockx /etc/X11/Xsession.d/60numlockx
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/numlockx true
	/usr/lib/linuxpanto/xfcepantoDesktop/tweaks/numlock/numlockx_on.sh
else
	gksu rm /etc/X11/Xsession.d/60numlockx
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/numlockx false
	/usr/lib/linuxpanto/xfcepantoDesktop/tweaks/numlock/numlockx_off.sh
fi