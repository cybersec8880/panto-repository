#!/bin/bash
if [ -f /usr/share/thumbnailers/video-thumbs.desktop ]; then
	/usr/lib/linuxpanto/xfcepantoDesktop/thumbnail/uninstaller.sh
else
	/usr/lib/linuxpanto/xfcepantoDesktop/thumbnail/installer.sh
fi