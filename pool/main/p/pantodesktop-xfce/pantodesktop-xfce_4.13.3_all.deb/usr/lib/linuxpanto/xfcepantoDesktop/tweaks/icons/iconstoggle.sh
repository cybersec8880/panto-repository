#!/bin/bash
white=$(cat $HOME/.gtkrc-2.0 | grep -i include | grep -i .gtkrc-white | wc -l)
black=$(cat $HOME/.gtkrc-2.0 | grep -i include | grep -i .gtkrc-black | wc -l)
CONTENT='
include ".gtkrc-white"
'
if [ ! -f $HOME/.gtkrc-2.0 ]; then
	touch $HOME/.gtkrc-2.0
fi
if [ ! -f $HOME/.gtkrc-white ]; then
	cp -f /usr/lib/linuxpanto/xfcepantoDesktop/tweaks/icons/.gtkrc-white $HOME/.gtkrc-white
fi
if [ "$white" = "1" ]; then
	cat $HOME/.gtkrc-2.0 >> newtmp
	sed '/include ".gtkrc-white"/ d' newtmp >newfile
	rm $HOME/.gtkrc-2.0
	mv newfile $HOME/.gtkrc-2.0
	rm newtmp
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_white false
	xfdesktop --quit
	xfdesktop &
	exit 0
elif [ "$black" = "1" ]; then
	cat $HOME/.gtkrc-2.0 >> newtmp
	sed '/include ".gtkrc-black"/ d' newtmp >newfile
	echo $CONTENT >> newfile
	rm $HOME/.gtkrc-2.0
	mv newfile $HOME/.gtkrc-2.0
	rm newtmp
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_white true
	xfdesktop --quit
	xfdesktop &
	exit 0
else
	echo $CONTENT >> $HOME/.gtkrc-2.0
	gconftool-2 --type bool --set /apps/pantodesktop-xfce/text_white true
	xfdesktop --quit
	xfdesktop &
	exit 0
fi