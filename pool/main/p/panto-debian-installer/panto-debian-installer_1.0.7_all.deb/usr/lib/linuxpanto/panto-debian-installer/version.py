#!/usr/bin/python

import apt
import sys

try:
	cache = apt.Cache()	
	pkg = cache["panto-debian-installer"]
	print pkg.installedVersion
except:
	pass


