#!/usr/bin/python2

import os
import sys
import gettext
import time
import threading
import urllib

import pygtk
pygtk.require("2.0")
import gtk
import gtk.glade

from pantoUploadCore import *

# i18n
gettext.install("pantoupload", "/usr/share/linuxpanto/locale")

global shutdown_flag
shutdown_flag = False


class NotifyThread(threading.Thread):

    def __init__(self, mainClass):
        threading.Thread.__init__(self)
        self.mainClass = mainClass

    def run(self):
        global shutdown_flag
        while not shutdown_flag:
            try:
                time.sleep(1)
                self.mainClass.reload_services()
            except:
                pass


class MainClass:

    def __init__(self):
        self.dropZones = {}

        self.statusIcon = gtk.StatusIcon()
        self.statusIcon.set_from_file("/usr/lib/linuxpanto/pantoUpload/systray.svg")

        try:
            desktop = os.environ["DESKTOP_SESSION"].lower()
            if desktop == "mate":
                self.statusIcon.set_from_icon_name("up")
        except Exception, detail:
            print detail

        self.statusIcon.set_tooltip(_("Upload services"))
        self.statusIcon.set_visible(True)

        self.statusIcon.connect('popup-menu', self.popup_menu_cb)
        self.statusIcon.connect('activate', self.show_menu_cb)

        self.reload_services()
        notifyT = NotifyThread(self)
        notifyT.start()

    def reload_services(self):
        self.services = read_services()
        self.menu = gtk.Menu()
        servicesMenuItem = gtk.ImageMenuItem()
        title = gtk.Label()
        title.set_text("<b><span foreground=\"grey\">" + _("Services:") + "</span></b>")
        title.set_justify(gtk.JUSTIFY_LEFT)
        title.set_alignment(0, 0.5)
        title.set_use_markup(True)
        servicesMenuItem.add(title)
        self.menu.append(servicesMenuItem)

        for service in self.services:
            serviceMenuItem = gtk.MenuItem(label="   " + service['name'])
            serviceMenuItem.connect("activate", self.create_drop_zone, service)
            self.menu.append(serviceMenuItem)

        self.menu.append(gtk.SeparatorMenuItem())

        uploadManagerMenuItem = gtk.MenuItem(_("Upload manager..."))
        uploadManagerMenuItem.connect('activate', self.launch_manager)
        self.menu.append(uploadManagerMenuItem)

        self.menu.append(gtk.SeparatorMenuItem())

        menuItem = gtk.ImageMenuItem(gtk.STOCK_QUIT)
        menuItem.connect('activate', self.quit_cb)
        self.menu.append(menuItem)
        self.menu.show_all()

    def launch_manager(self, widget):
        os.system("/usr/lib/linuxpanto/pantoUpload/upload-manager.py &")

    def create_drop_zone(self, widget, service):
        if service['name'] not in self.dropZones.keys():
            dropZone = DropZone(self.statusIcon, self.menu, service, self.dropZones)
            self.dropZones[service['name']] = dropZone
        else:
            self.dropZones[service['name']].show()

    def quit_cb(self, widget):
        self.statusIcon.set_visible(False)
        global shutdown_flag
        shutdown_flag = True
        gtk.main_quit()
        sys.exit(0)

    def show_menu_cb(self, widget):
        self.menu.popup(None, None, self.menu_pos, 0, gtk.get_current_event_time())

    def popup_menu_cb(self, widget, button, activate_time):
        self.menu.popup(None, None, self.menu_pos, button, activate_time)

    def menu_pos(self, menu):
        return gtk.status_icon_position_menu(self.menu, self.statusIcon)


class DropZone:

    def __init__(self, statusIcon, menu, service, dropZones):
        self.service = service
        self.statusIcon = statusIcon
        self.dropZones = dropZones
        self.menu = menu
        self.w = gtk.Window()

        TARGET_TYPE_TEXT = 80
        self.w.drag_dest_set(gtk.DEST_DEFAULT_MOTION | gtk.DEST_DEFAULT_HIGHLIGHT | gtk.DEST_DEFAULT_DROP, [("text/uri-list", 0, TARGET_TYPE_TEXT)], gtk.gdk.ACTION_MOVE | gtk.gdk.ACTION_COPY)
        self.w.connect('drag_motion', self.motion_cb)
        self.w.connect('drag_drop', self.drop_cb)
        self.w.connect('drag_data_received', self.drop_data_received_cb)
        self.w.connect('destroy', self.destroy_cb)
        self.w.set_icon_from_file("/usr/lib/linuxpanto/pantoUpload/icon.svg")
        self.w.set_title(self.service['name'])
        self.w.set_keep_above(True)
        self.w.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_UTILITY)
        self.w.set_skip_pager_hint(True)
        self.w.set_skip_taskbar_hint(True)
        self.w.stick()

        pos = gtk.status_icon_position_menu(self.menu, self.statusIcon)
        posY = len(self.dropZones) * 80
        self.w.move(pos[0], pos[1] + 50 - posY)

        self.label = gtk.Label()
        self.label.set_text("<small>" + _("Drag &amp; Drop here to upload to %s") % self.service['name'] + "</small>")
        self.label.set_line_wrap(True)
        self.label.set_use_markup(True)
        self.label.set_width_chars(20)
        self.w.add(self.label)

        self.w.set_default_size(100, 50)

        if self.w.is_composited():
            self.w.set_opacity(0.5)

        self.w.show_all()

    def show(self):
        self.w.show_all()
        self.w.present()

    def motion_cb(self, wid, context, x, y, time):
        context.drag_status(gtk.gdk.ACTION_COPY, time)
        return True

    def drop_cb(self, wid, context, x, y, time):
        context.finish(True, False, time)
        return True

    def drop_data_received_cb(self, widget, context, x, y, selection, targetType, time):
        filenames = []
        files = selection.data.split('\n')
        for f in files:
            if not f:
                continue
            f = urllib.url2pathname(f)
            f = f.strip('\r')
            f = f.replace("file://", "")
            f = f.replace("'", r"'\''")
            f = "'" + f + "'"
            filenames.append(f)

        os.system("pantoupload \"" + self.service['name'] + "\" " + " ".join(filenames) + " &")

    def destroy_cb(self, wid):
        del self.dropZones[self.service['name']]

gtk.gdk.threads_init()
gtk.gdk.threads_enter()
MainClass()
gtk.main()
gtk.gdk.threads_leave()
