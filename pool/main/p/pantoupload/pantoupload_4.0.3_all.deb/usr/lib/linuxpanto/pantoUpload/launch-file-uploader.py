#!/usr/bin/python2

import os
from pantoUploadCore import *

services = read_services()
if len(services) > 0:
    os.system("/usr/lib/linuxpanto/pantoUpload/file-uploader.py &")
