#!/bin/bash
$1 &
