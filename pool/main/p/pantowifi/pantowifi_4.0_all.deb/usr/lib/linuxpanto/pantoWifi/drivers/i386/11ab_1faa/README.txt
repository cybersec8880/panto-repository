List of affected cards:

- 3COM 3CRGPC10075
- Airnet AWD154 and AWN154
- Airlink+ 802.11g Model AWLC3026
- Digitus DN-7001G MV (802.11a/b/g) PCMCIA
- Encore Electronics ENLWI-G and ENPWI-G
- Linksys WPC54G v5 (tested!)
- Mentor WLG-PCI and WLG-PCII
- Netgear WG311 v3 and WG511 v2
- Netcow FC-NC9010
- NogaNet TWL542C PCMCIA
- Option globetrotter (GT) Fusion
- Peabird PEAB-WLG-PCI
- Trendnet TEW-421PC

