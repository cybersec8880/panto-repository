Card: Asus WL-107G, 54mbps Cardbus PCMCIA

    * Chipset: RaLink RT2500
    * pciid: 1814:0201. Should work for any rt2500-based PCI/PCMCIA/MiniPCI card listed here
    * Driver: Ralink's own windows executable version 3.2.0.0 or extracted and re-tarballed
    * Other: Perfect WPA (Proper security)! Ndiswrapper 1.21 (latest stable), Debian Etch (linux 2.6.16). LED reversal problem fixed (now led is lit only for traffic). Consistent, stable 1.3MB/s with WPA! BTW, I've diffed the win2k and winXP drivers, and they're identical. 20060724. 