List of affected cards:

- Alpha AFW-N411
- Acer Aspise 1353 LCi
- D-Link DWL-520 (Rev D1) and Air DWL-650
- Digicom Palladio Wave C
- Edimax EW-7106PC and EW-7126PC
- Encore Electronics ENPWI-B-RECA
- Gericom PANWL 1102
- Gigafast WF721-AEX
- Hamlet HNWP110
- Intellinet (Prod ID 521710)
- Jensen Scandinavia Air:Link 6011 PCMCIA
- Linksys WPC11 v.4
- Longshine LCS-8531-R PCMCIA
- Mercury/Kobian KOB WL445
- Planet WL-8303
- Sweex Essentials Wireless PCI
- TP-LINK TL-WN250 (ver 2.0) PCI
- Topcom skyr@cer 4011b and skyr@cer PCI 111
- Trendnet TEW-226PC and TEW-228PI
- X-Micro XWL-11BPRG

